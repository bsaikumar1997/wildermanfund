<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wildermanfund' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'OS;j.*UQ-^Qv%KGJ]wn59aPs#t$N<gx^{l|?ZJZv.2}=[VDGQ=ymq37bnqOu]ZKL' );
define( 'SECURE_AUTH_KEY',  '24z/{SJ,XcY#VT!!]eWmw`(PUj*OM_8RG9c- ~]g;}!WMyd}{0+-%T:&h=UR&z,X' );
define( 'LOGGED_IN_KEY',    'kgH`fcPJ2w61j(@u<ly33V4E<v}n}aL6%5;Ir 1kg[s8sW0R}oz:h:WdHG*ma9|I' );
define( 'NONCE_KEY',        'Y*Cq^zks5o}Z.%35x8p(Ojh((2bkz70Ae^*MYcQz.A]AF-ryTvf8)t*g]h1]wG}L' );
define( 'AUTH_SALT',        'rc%/Mh?YY=lFe4L5$yD3d|1JQ-~e.i6UX8JR]IG_y2do{blEq|,K&l2RHJ9fjgS-' );
define( 'SECURE_AUTH_SALT', 'P::/rI_,@J}usZ4@h#pad(:aBXyaqbV2;0<]|i2>16w;#;{u4$rIh_Se:s3,YW B' );
define( 'LOGGED_IN_SALT',   'bA},y!Mwc@Guq##lxD3>LeJ$thaUiBnu7za_(?6uo^?L BwRFjX35.]eF|k6Bh&4' );
define( 'NONCE_SALT',       'c12|xp}.vYQ%WUB/;_4A:VGySSoTC6_E?D+T91{Trzf6ZeM[u=WGAcX.I4O{VDaM' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
